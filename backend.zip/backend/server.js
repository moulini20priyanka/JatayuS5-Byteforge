if (typeof DOMMatrix === 'undefined') { global.DOMMatrix = class DOMMatrix {}; }
if (typeof ImageData === 'undefined') { global.ImageData = class ImageData {}; }

const express            = require("express");
const cors               = require("cors");
const dotenv             = require("dotenv");
const { v4: uuidv4 }     = require("uuid");
const mssql              = require("mssql");
const cron               = require("node-cron");
const stringSimilarity   = require("string-similarity");
const esprima            = require("esprima");
const crypto             = require("crypto");
const jwt                = require("jsonwebtoken");
const aiProxy            = require('./routes/aiProxy');
const { trace }          = require('./utils/tracer');

dotenv.config();

// ─── SQL Server connection ────────────────────────────────────────────────────
const sqlConfig = {
  server:   process.env.DB_HOST,
  user:     process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
  port:     1433,
  options:  { encrypt: true, trustServerCertificate: false },
  pool:     { max: 10, min: 0, idleTimeoutMillis: 30000 },
};

const poolPromise = new mssql.ConnectionPool(sqlConfig).connect()
  .then(p  => { console.log("✅ Connected to Azure SQL Server"); return p; })
  .catch(e => { console.error("❌ DB Connection failed:", e.message); process.exit(1); });

// Converts ? placeholders → @p0, @p1 … and returns [recordset, []]
async function runQuery(queryStr, params = []) {
  const pool = await poolPromise;
  const request = new mssql.Request(pool);
  let i = 0;
  const converted = queryStr.replace(/\?/g, () => {
    const name = `p${i}`;
    request.input(name, params[i]);
    i++;
    return `@${name}`;
  });
  const result = await request.query(converted);
  return [result.recordset ?? [], []];
}

// Drop-in replacement for mysql2 pool — same API surface
const pool = {
  query:   async (q, p = []) => runQuery(q, p),
  execute: async (q, p = []) => runQuery(q, p),
  getConnection: async () => {
    const conn = await poolPromise;
    let tx = null;
    return {
      query:   async (q, p = []) => runQuery(q, p),
      execute: async (q, p = []) => runQuery(q, p),
      beginTransaction: async () => {
        tx = new mssql.Transaction(conn);
        await tx.begin();
      },
      commit:   async () => { if (tx) { await tx.commit();   tx = null; } },
      rollback: async () => { if (tx) { await tx.rollback(); tx = null; } },
      release:  () => {},
    };
  },
};
// ─────────────────────────────────────────────────────────────────────────────

const app = express();

app.use(cors());
app.options(/.*/, cors());

app.use(express.json({ limit: "10mb" }));

app.use('/api/ai-analyst', aiProxy);
app.use('/api/langsmith', require('./routes/langsmithProxy'));
app.use('/api/execute',   require('./routes/execute'));

// ─── Health check ─────────────────────────────────────────────────────────────
app.get("/api/health", async (req, res) => {
  const health = {
    status: "ok",
    message: "NeuroAssess backend is running",
    port: process.env.PORT || 5000,
    environment: process.env.NODE_ENV || "development",
    time: new Date().toISOString(),
    database: "unknown",
  };
  try {
    await runQuery("SELECT 1 AS ping");
    health.database = "connected";
  } catch (err) {
    health.database = "error: " + err.message;
    health.status = "degraded";
  }
  const statusCode = health.status === "ok" ? 200 : 503;
  res.status(statusCode).json(health);
});
// ─────────────────────────────────────────────────────────────────────────────

const JWT_SECRET = process.env.JWT_SECRET || process.env.JWT_SECRET_KEY || "neuroassess_secret_2024";

app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/settings',      require('./routes/settings'));

let AuditLogger = null;
try { AuditLogger = require("./services/auditLogger"); console.log("✅ AuditLogger loaded"); }
catch (e) { console.error("❌ AuditLogger failed:", e.message); }

async function auditLog(method, ...args) {
  if (!AuditLogger || typeof AuditLogger[method] !== "function") return;
  try { await AuditLogger[method](...args); } catch (e) { console.error(`[AuditLog] ${method}:`, e.message); }
}

async function getAuditUser(req) {
  try {
    const token = (req.headers.authorization || '').replace('Bearer ', '').trim();
    if (!token) return { userId: null, username: 'Unknown' };
    const dec = jwt.verify(token, JWT_SECRET);
    return { userId: dec.id || dec.userId || null, username: dec.email || dec.name || 'Unknown' };
  } catch { return { userId: null, username: 'Unknown' }; }
}

function getClientInfo(req) {
  return {
    ipAddress: req.headers['x-forwarded-for']?.split(',')[0].trim() || req.connection?.remoteAddress || 'Unknown',
    userAgent: req.headers['user-agent'] || 'Unknown',
  };
}

function resolveRouter(mod, filePath) {
  if (!mod) return null;
  if (typeof mod === 'function') return mod;
  if (typeof mod === 'object') {
    for (const key of ['router', 'default', 'handler']) {
      if (mod[key] && typeof mod[key] === 'function') return mod[key];
    }
    console.error(`❌ ${filePath} exports object but no usable router key. Keys: ${Object.keys(mod).join(', ')}`);
    return null;
  }
  return null;
}

function safeRequire(filePath) {
  try {
    const raw = require(filePath);
    const mod = resolveRouter(raw, filePath);
    if (mod) console.log(`✅ ${filePath}`);
    return mod;
  } catch (err) {
    console.error(`❌ Failed to load: ${filePath}\n   ${err.message}`);
    return null;
  }
}

function useRoute(mountPath, mod, label) {
  if (!mod) { console.error(`⚠️  Skipping ${label} — not a valid router`); return; }
  app.use(mountPath, mod);
  console.log(`🔗 Mounted ${label} at ${mountPath}`);
}

function genQBId() { return 'QB-' + Math.random().toString(36).substr(2, 6).toUpperCase(); }

function resolveCorrectAns(q) {
  const raw = q.correct_ans || q.answer || null;
  if (!raw) return null;
  if (/^[A-Da-d]$/.test(String(raw).trim())) return String(raw).trim().toUpperCase();
  const opts = [
    { key: 'A', text: q.option_a || q.options?.[0]?.text },
    { key: 'B', text: q.option_b || q.options?.[1]?.text },
    { key: 'C', text: q.option_c || q.options?.[2]?.text },
    { key: 'D', text: q.option_d || q.options?.[3]?.text },
  ];
  const match = opts.find(o => o.text && o.text.trim().toLowerCase() === String(raw).trim().toLowerCase());
  return match ? match.key : null;
}

const QB_TYPE_MAP = {
  mcq: 'mcq', MCQ: 'mcq', coding: 'coding', Coding: 'coding',
  sql: 'sql', SQL: 'sql', aptitude: 'aptitude', Aptitude: 'aptitude',
  verbal: 'verbal', Verbal: 'verbal', theory: 'theory', Theory: 'theory',
};
const QB_DIFF_MAP = {
  easy: 'easy', Easy: 'easy', medium: 'medium',
  Medium: 'medium', hard: 'hard', Hard: 'hard',
};

// ─── Question Bank routes ─────────────────────────────────────────────────────

app.get('/api/question-bank', async (req, res) => {
  try {
    const { type, difficulty, search } = req.query;
    let sql = 'SELECT * FROM question_bank WHERE is_active = 1';
    const params = [];
    if (type && type !== 'All') { sql += ' AND type = ?'; params.push(type.toLowerCase()); }
    if (difficulty && difficulty !== 'All') { sql += ' AND difficulty = ?'; params.push(difficulty.toLowerCase()); }
    if (search) {
      sql += ' AND (topic LIKE ? OR question_text LIKE ? OR qb_id LIKE ?)';
      const s = `%${search}%`; params.push(s, s, s);
    }
    sql = sql.replace('SELECT *', 'SELECT TOP 500 *');
    sql += ' ORDER BY created_at DESC';
    const [rows] = await pool.query(sql, params);
    res.json(rows.map(q => ({
      id: q.qb_id, _dbId: q.id, topic: q.topic,
      type: q.type === 'mcq' ? 'MCQ' : q.type.charAt(0).toUpperCase() + q.type.slice(1),
      difficulty: q.difficulty.charAt(0).toUpperCase() + q.difficulty.slice(1),
      source: q.source || 'QuizForge AI',
      createdDate: new Date(q.created_at).toLocaleDateString('en-GB'),
      question_text: q.question_text, option_a: q.option_a, option_b: q.option_b,
      option_c: q.option_c, option_d: q.option_d,
      correct_ans: q.correct_ans, marks: q.marks || null, mark_type: q.mark_type || null,
      bloom_level: q.bloom_level || null, subject: q.subject || null,
      key_points: q.key_points || null, keywords: q.keywords || null,
      expected_answer: q.expected_answer || null,
      model_answer_outline: q.model_answer_outline || null,
    })));
  } catch (err) { console.error('[QB GET]', err); res.status(500).json({ error: err.message }); }
});

app.get('/api/question-bank/stats', async (req, res) => {
  try {
    const [byType] = await pool.query(
      `SELECT type, COUNT(*) AS count FROM question_bank WHERE is_active = 1 GROUP BY type ORDER BY count DESC`
    );
    const [totalRows] = await pool.query(`SELECT COUNT(*) AS total FROM question_bank WHERE is_active = 1`);
    const total = totalRows[0]?.total ?? 0;
    res.json({ total, breakdown: byType });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/question-bank/import', async (req, res) => {
  const { questions, examName, sessionCode, examType } = req.body;
  if (!Array.isArray(questions) || questions.length === 0)
    return res.status(400).json({ error: 'questions array required' });
  const { userId, username } = await getAuditUser(req);
  const { ipAddress, userAgent } = getClientInfo(req);
  try {
    const saved = [];
    for (const q of questions) {
      const qbId   = genQBId();
      const qType  = QB_TYPE_MAP[q.type] || 'mcq';
      const qDiff  = QB_DIFF_MAP[q.difficulty] || 'medium';
      const isTheory = qType === 'theory';
      const topic  = (q.topic || q.subject || (q.question || '').substring(0, 60) || 'QuizForge Question').trim();
      const qText  = (q.question || q.question_text || topic).toString().trim();

      const [result] = await pool.query(
        `INSERT INTO question_bank
           (qb_id, topic, question_text, question, type, difficulty,
            option_a, option_b, option_c, option_d, correct_ans,
            marks, mark_type, bloom_level, subject,
            key_points, keywords, expected_answer, model_answer_outline,
            explanation, language_tag, topic_tag,
            source, created_by, created_at)
         OUTPUT INSERTED.id
         VALUES
           (?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?,
            'QuizForge AI', 1, GETDATE())`,
        [
          qbId, topic, qText, qText, qType, qDiff,
          isTheory ? null : (q.option_a || q.options?.[0]?.text || null),
          isTheory ? null : (q.option_b || q.options?.[1]?.text || null),
          isTheory ? null : (q.option_c || q.options?.[2]?.text || null),
          isTheory ? null : (q.option_d || q.options?.[3]?.text || null),
          isTheory ? null : resolveCorrectAns(q),
          isTheory ? (q.marks || 5) : null,
          isTheory ? (q.mark_type || `${q.marks || 5}m`) : null,
          isTheory ? (q.bloom_level || null) : null,
          isTheory ? (q.subject || topic) : null,
          isTheory ? JSON.stringify(Array.isArray(q.key_points) ? q.key_points : []) : null,
          isTheory ? (Array.isArray(q.keywords) ? q.keywords.join(', ') : (q.keywords || null)) : null,
          isTheory ? (q.expected_answer || q.explanation || null) : null,
          isTheory ? (q.model_answer_outline || null) : null,
          q.explanation || null,
          isTheory ? null : (q.language_tag || q.language || null),
          q.topic_tag || topic || null,
        ]
      );
      const insertedId = result[0]?.id ?? null;
      saved.push({
        id: qbId, _dbId: insertedId, topic,
        type: qType === 'mcq' ? 'MCQ' : qType.charAt(0).toUpperCase() + qType.slice(1),
        difficulty: qDiff.charAt(0).toUpperCase() + qDiff.slice(1),
        source: 'QuizForge AI', createdDate: new Date().toLocaleDateString('en-GB'),
        question: qText, question_text: qText,
        options: isTheory ? [] : (q.options || []),
        answer: isTheory ? null : (q.answer || ''),
        explanation: q.explanation || '',
        marks: isTheory ? (q.marks || 5) : null,
        mark_type: isTheory ? (q.mark_type || `${q.marks || 5}m`) : null,
        bloom_level: isTheory ? (q.bloom_level || null) : null,
        subject: isTheory ? (q.subject || topic) : null,
        key_points: isTheory ? (Array.isArray(q.key_points) ? q.key_points : []) : [],
        keywords: isTheory ? (q.keywords || '') : '',
      });
    }
    const source = examName
      ? `${examName}${sessionCode ? ` (session: ${sessionCode})` : ''}`
      : 'QuizForge AI — server.js inline import';
    await auditLog('logQuestionsBulkImported', userId, username, saved.length, source, ipAddress, userAgent);
    res.status(201).json({ success: true, count: saved.length, questions: saved });
  } catch (err) { console.error('[QB Import]', err); res.status(500).json({ error: err.message }); }
});

app.post('/api/question-bank', async (req, res) => {
  try {
    const { topic, type, difficulty } = req.body;
    if (!topic) return res.status(400).json({ error: 'topic required' });
    const qbId  = genQBId();
    const qType = QB_TYPE_MAP[type] || 'mcq';
    const qDiff = QB_DIFF_MAP[difficulty] || 'medium';
    const [result] = await pool.query(
      `INSERT INTO question_bank (qb_id, topic, question_text, type, difficulty, source, created_by, created_at)
       OUTPUT INSERTED.id
       VALUES (?, ?, ?, ?, ?, 'Manual', 1, GETDATE())`,
      [qbId, topic, topic, qType, qDiff]
    );
    const insertedId = result[0]?.id ?? null;
    res.status(201).json({
      id: qbId, _dbId: insertedId, topic,
      type: qType === 'mcq' ? 'MCQ' : qType.charAt(0).toUpperCase() + qType.slice(1),
      difficulty: qDiff.charAt(0).toUpperCase() + qDiff.slice(1),
      source: 'Manual', createdDate: new Date().toLocaleDateString('en-GB'),
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/question-bank/:qbId', async (req, res) => {
  try {
    await pool.query('UPDATE question_bank SET is_active = 0 WHERE qb_id = ?', [req.params.qbId]);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// NOTE: /api/exams and all exam sub-routes are handled by routes/exams.js (mounted below).
// The old inline versions have been removed to prevent route conflicts.

console.log('✅ Question Bank routes registered');

// ─── Create tables (SQL Server DDL) ──────────────────────────────────────────
async function createTables() {
  const conn = await pool.getConnection();
  try {
    await conn.execute(`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='university_exam_assignments' AND xtype='U')
      CREATE TABLE university_exam_assignments (
        id           INT IDENTITY(1,1) PRIMARY KEY,
        exam_id      INT NOT NULL,
        student_id   VARCHAR(100) NOT NULL,
        status       VARCHAR(20)  DEFAULT 'assigned',
        exam_key     VARCHAR(50),
        score        DECIMAL(8,2) DEFAULT NULL,
        answers      NVARCHAR(MAX) DEFAULT NULL,
        started_at   DATETIME DEFAULT NULL,
        submitted_at DATETIME DEFAULT NULL,
        assigned_at  DATETIME DEFAULT GETDATE()
      )`);
    console.log("✓ university_exam_assignments table ensured");

    await conn.execute(`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='student_exam_questions' AND xtype='U')
      CREATE TABLE student_exam_questions (
        id            INT IDENTITY(1,1) PRIMARY KEY,
        assignment_id INT NOT NULL,
        question_type VARCHAR(20) NOT NULL DEFAULT 'mcq',
        question_ids  NVARCHAR(MAX) NOT NULL,
        created_at    DATETIME DEFAULT GETDATE()
      )`);
    console.log("✓ student_exam_questions table ensured");

    await conn.execute(`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='viva_results' AND xtype='U')
      CREATE TABLE viva_results (
        id            INT IDENTITY(1,1) PRIMARY KEY,
        student_name  VARCHAR(255),
        problem_name  VARCHAR(255),
        submitted_code NVARCHAR(MAX),
        coding_score  FLOAT,
        overall_score FLOAT,
        auth_score    FLOAT,
        final_verdict VARCHAR(50),
        completed_at  VARCHAR(50),
        created_at    DATETIME DEFAULT GETDATE()
      )`);

    await conn.execute(`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='viva_answers' AND xtype='U')
      CREATE TABLE viva_answers (
        id                 INT IDENTITY(1,1) PRIMARY KEY,
        viva_result_id     INT NOT NULL,
        question_number    INT,
        question_type      VARCHAR(100),
        question           NVARCHAR(MAX),
        student_answer     NVARCHAR(MAX),
        duration_secs      INT,
        score              FLOAT,
        technical_accuracy FLOAT,
        relevance          FLOAT,
        completeness       FLOAT,
        authenticity_score FLOAT,
        verdict            VARCHAR(50),
        feedback           NVARCHAR(MAX),
        strengths          NVARCHAR(MAX),
        improvements       NVARCHAR(MAX),
        authenticity_reason NVARCHAR(MAX),
        created_at         DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (viva_result_id) REFERENCES viva_results(id)
      )`);
    console.log("✓ Viva tables ready");

    await conn.execute(`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='code_snapshots' AND xtype='U')
      CREATE TABLE code_snapshots (
        id         BIGINT IDENTITY(1,1) PRIMARY KEY,
        student_id VARCHAR(100) NOT NULL,
        exam_id    INT NOT NULL,
        code       NVARCHAR(MAX) NOT NULL,
        created_at DATETIME DEFAULT GETDATE()
      )`);

    await conn.execute(`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='plagiarism_reports' AND xtype='U')
      CREATE TABLE plagiarism_reports (
        id           BIGINT IDENTITY(1,1) PRIMARY KEY,
        student_id   VARCHAR(100) NOT NULL,
        exam_id      INT NOT NULL,
        score        FLOAT DEFAULT 0,
        matched_with VARCHAR(100) DEFAULT NULL,
        change_count INT DEFAULT 0,
        checked_at   DATETIME DEFAULT GETDATE()
      )`);
    console.log("✓ Plagiarism tables ready");

    await conn.execute(`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ai_detection_reports' AND xtype='U')
      CREATE TABLE ai_detection_reports (
        id               BIGINT IDENTITY(1,1) PRIMARY KEY,
        student_id       VARCHAR(100) NOT NULL,
        exam_id          INT NOT NULL,
        ai_score         FLOAT DEFAULT 0,
        verdict          VARCHAR(50)  DEFAULT 'Human Written',
        confidence       VARCHAR(20)  DEFAULT 'Low',
        signals          NVARCHAR(MAX),
        ast_depth        INT DEFAULT 0,
        unique_vars      INT DEFAULT 0,
        avg_line_length  FLOAT DEFAULT 0,
        comment_ratio    FLOAT DEFAULT 0,
        sudden_paste     SMALLINT DEFAULT 0,
        perfect_structure SMALLINT DEFAULT 0,
        checked_at       DATETIME DEFAULT GETDATE()
      )`);
    console.log("✓ AI Detection table ready");

    await conn.execute(`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='audit_logs' AND xtype='U')
      CREATE TABLE audit_logs (
        id              INT IDENTITY(1,1) PRIMARY KEY,
        user_id         INT DEFAULT NULL,
        username        VARCHAR(255)  NOT NULL DEFAULT 'System',
        action_type     VARCHAR(100)  NOT NULL,
        action_category VARCHAR(100)  NOT NULL,
        entity_type     VARCHAR(100)  DEFAULT NULL,
        entity_id       VARCHAR(100)  DEFAULT NULL,
        entity_name     VARCHAR(500)  DEFAULT NULL,
        status          VARCHAR(50)   NOT NULL DEFAULT 'SUCCESS',
        details         NVARCHAR(MAX) DEFAULT NULL,
        ip_address      VARCHAR(100)  DEFAULT 'Unknown',
        user_agent      NVARCHAR(MAX) DEFAULT NULL,
        timestamp       DATETIME      NOT NULL DEFAULT GETDATE()
      )`);
    console.log("✓ audit_logs table ready");

    await conn.execute(`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='candidate_agent_cache' AND xtype='U')
      CREATE TABLE candidate_agent_cache (
        id           INT IDENTITY(1,1) PRIMARY KEY,
        candidate_id VARCHAR(100) NOT NULL UNIQUE,
        github_data   NVARCHAR(MAX) DEFAULT NULL,
        leetcode_data NVARCHAR(MAX) DEFAULT NULL,
        fetched_at    DATETIME DEFAULT GETDATE()
      )`);
    console.log("✓ candidate_agent_cache table ready");

  } catch (err) {
    console.error("Error creating tables:", err.message);
  } finally {
    conn.release();
  }
}

// ─── AI / Plagiarism detection helpers ───────────────────────────────────────

function detectAIGeneratedCode(code, snapshots) {
  const signals = []; let aiScore = 0;
  const lines = code.split("\n");
  const nonEmptyLines = lines.filter(l => l.trim().length > 0);
  let suddenPaste = 0;
  if (snapshots && snapshots.length >= 2) {
    for (let i = 1; i < snapshots.length; i++) {
      if (snapshots[i].code.length - snapshots[i - 1].code.length > 300) {
        suddenPaste = 1; signals.push("Large code block appeared suddenly"); aiScore += 25; break;
      }
    }
  }
  const commentLines = lines.filter(l => {
    const t = l.trim();
    return t.startsWith("//") || t.startsWith("*") || t.startsWith("/*") || t.startsWith("#") || t.startsWith('"""');
  });
  const commentRatio = commentLines.length / Math.max(lines.length, 1);
  if (commentRatio > 0.20) { signals.push(`High comment ratio (${(commentRatio * 100).toFixed(0)}%)`); aiScore += 20; }
  const avgLineLength = nonEmptyLines.reduce((a, l) => a + l.length, 0) / Math.max(nonEmptyLines.length, 1);
  if (avgLineLength > 40) { signals.push(`Long avg line length (${avgLineLength.toFixed(0)} chars)`); aiScore += 15; }
  if (snapshots && snapshots.length <= 2 && code.length > 200) {
    signals.push("Very few edits for long submission"); aiScore += 20;
  }
  const indentedLines = lines.filter(l => l.startsWith("    ") || l.startsWith("\t"));
  if (indentedLines.length / Math.max(lines.length, 1) > 0.45 && lines.length > 8) {
    signals.push("Perfectly consistent indentation"); aiScore += 10;
  }
  const aiStyleNames = [
    "complement","solution","result","current","target","helper","optimal","efficient",
    "HashMap","ArrayList","StringBuilder","initialize","iterate","traverse","compute",
    "calculate","implement","approach","algorithm","complexity","containsKey",
    "getOrDefault","entrySet","keySet","putIfAbsent",
  ];
  const aiNameMatches = code.split(/\W+/).filter(w => aiStyleNames.includes(w)).length;
  if (aiNameMatches >= 2) { signals.push(`AI-style variable names (${aiNameMatches} matches)`); aiScore += 15; }
  if (code.includes("class Solution") || code.includes("public static") || code.includes("public int")) {
    const hasComplete = code.includes("public") && (code.includes("return") || code.includes("void")) && code.includes("{");
    if (hasComplete && nonEmptyLines.length > 8) { signals.push("Complete Java class structure"); aiScore += 10; }
    if (code.includes("HashMap") || code.includes("Map<")) { signals.push("Optimized data structure usage"); aiScore += 10; }
  }
  if (code.includes("def ") && code.includes(":")) {
    if (code.includes("enumerate") || code.includes("zip(") || code.includes("defaultdict")) {
      signals.push("Advanced Python patterns"); aiScore += 15;
    }
    if (code.includes("List[") || code.includes("Dict[") || code.includes("Optional[")) {
      signals.push("Python type hints"); aiScore += 10;
    }
  }
  let perfectStructure = 0, astDepth = 0, uniqueVars = 0;
  try {
    esprima.parseScript(code, { tolerant: false });
    if (lines.length > 10) { perfectStructure = 1; signals.push("Syntactically perfect JS"); aiScore += 10; }
  } catch {}
  try {
    const ast = esprima.parseScript(code, { tolerant: true });
    function measureDepth(n, d = 0) {
      if (!n || typeof n !== 'object') return d;
      if (Array.isArray(n)) return Math.max(0, ...n.map(x => measureDepth(x, d)));
      let max = d;
      for (const k of Object.keys(n)) { if (k !== 'type') { const c = measureDepth(n[k], d + 1); if (c > max) max = c; } }
      return max;
    }
    const varNames = new Set();
    function collectVars(n) {
      if (!n || typeof n !== 'object') return;
      if (Array.isArray(n)) { n.forEach(collectVars); return; }
      if (n.type === "Identifier" && n.name) varNames.add(n.name);
      Object.values(n).forEach(v => collectVars(v));
    }
    astDepth = measureDepth(ast); collectVars(ast); uniqueVars = varNames.size;
    if (astDepth > 12) { signals.push(`Deep AST (depth ${astDepth})`); aiScore += 10; }
    if (uniqueVars > 15) { signals.push(`Many identifiers (${uniqueVars})`); aiScore += 5; }
  } catch {}
  aiScore = Math.min(Math.round(aiScore), 100);
  let verdict = "Human Written", confidence = "High";
  if (aiScore >= 70)      { verdict = "AI Generated"; confidence = "High"; }
  else if (aiScore >= 45) { verdict = "Likely AI";    confidence = "Medium"; }
  else if (aiScore >= 25) { verdict = "Possibly AI";  confidence = "Low"; }
  return {
    aiScore, verdict, confidence, signals, astDepth, uniqueVars,
    avgLineLength: parseFloat(avgLineLength.toFixed(2)),
    commentRatio: parseFloat((commentRatio * 100).toFixed(2)),
    suddenPaste, perfectStructure,
  };
}

function normalizeCodeAST(code) {
  try {
    const ast = esprima.parseScript(code, { tolerant: true });
    let counter = 0; const nameMap = new Map();
    function rename(n) { if (!nameMap.has(n)) nameMap.set(n, `v${counter++}`); return nameMap.get(n); }
    function walk(node) {
      if (!node || typeof node !== 'object') return node;
      if (Array.isArray(node)) return node.map(walk);
      const out = {};
      for (const key of Object.keys(node)) {
        if (key === 'type') out[key] = node[key];
        else if ((node.type === 'Identifier' || node.type === 'VariableDeclarator') && key === 'name') out[key] = rename(node[key]);
        else out[key] = walk(node[key]);
      }
      return out;
    }
    return JSON.stringify(walk(ast));
  } catch {
    return code.replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '').replace(/\s+/g, ' ').trim();
  }
}

async function checkPlagiarism(studentId, examId, studentCode) {
  const [others] = await pool.execute(
    `SELECT cs.student_id, cs.code FROM code_snapshots cs
     INNER JOIN (
       SELECT student_id, MAX(created_at) AS latest
       FROM code_snapshots WHERE exam_id=? AND student_id!=?
       GROUP BY student_id
     ) t ON cs.student_id=t.student_id AND cs.created_at=t.latest`,
    [examId, studentId]
  );
  if (!others.length) return { score: 0, matchedWith: null };
  const ns = normalizeCodeAST(studentCode);
  let maxScore = 0, matchedWith = null;
  for (const row of others) {
    const no = normalizeCodeAST(row.code);
    const combined = Math.max(
      stringSimilarity.compareTwoStrings(ns, no),
      stringSimilarity.compareTwoStrings(
        studentCode.replace(/\s+/g, ' ').trim(),
        row.code.replace(/\s+/g, ' ').trim()
      )
    );
    if (combined > maxScore) { maxScore = combined; matchedWith = row.student_id; }
  }
  return { score: parseFloat((maxScore * 100).toFixed(2)), matchedWith };
}

// ─── Cron: plagiarism + AI detection ─────────────────────────────────────────
cron.schedule("*/2 * * * *", async () => {
  try {
    const [activePairs] = await pool.execute(
      `SELECT DISTINCT student_id, exam_id FROM code_snapshots WHERE created_at >= DATEADD(MINUTE, -10, GETDATE())`
    );
    for (const { student_id, exam_id } of activePairs) {
      const parsedExamId = typeof exam_id === 'string' ? parseInt(exam_id) : exam_id;
      if (isNaN(parsedExamId)) continue;
      const [latestRows] = await pool.execute(
        `SELECT TOP 1 code FROM code_snapshots WHERE student_id=? AND exam_id=? ORDER BY created_at DESC`,
        [student_id, parsedExamId]
      );
      const latest = latestRows[0];
      if (!latest?.code) continue;
      const [snapshots] = await pool.execute(
        `SELECT code, created_at FROM code_snapshots WHERE student_id=? AND exam_id=? ORDER BY created_at ASC`,
        [student_id, parsedExamId]
      );
      const { score, matchedWith } = await checkPlagiarism(student_id, parsedExamId, latest.code);
      const [ccRows] = await pool.execute(
        `SELECT COUNT(*) AS change_count FROM code_snapshots WHERE student_id=? AND exam_id=?`,
        [student_id, parsedExamId]
      );
      const change_count = ccRows[0]?.change_count ?? 0;
      await pool.execute(
        `MERGE plagiarism_reports AS target
         USING (SELECT ? AS student_id, ? AS exam_id) AS src
           ON target.student_id = src.student_id AND target.exam_id = src.exam_id
         WHEN MATCHED THEN
           UPDATE SET
             score        = CASE WHEN ? > target.score THEN ? ELSE target.score END,
             matched_with = CASE WHEN ? > target.score THEN ? ELSE target.matched_with END,
             change_count = ?,
             checked_at   = GETDATE()
         WHEN NOT MATCHED THEN
           INSERT (student_id, exam_id, score, matched_with, change_count, checked_at)
           VALUES (?, ?, ?, ?, ?, GETDATE());`,
        [
          student_id, parsedExamId,
          score, score,
          score, matchedWith,
          change_count,
          student_id, parsedExamId, score, matchedWith, change_count,
        ]
      );
      const ai = detectAIGeneratedCode(latest.code, snapshots);
      await pool.execute(
        `MERGE ai_detection_reports AS target
         USING (SELECT ? AS student_id, ? AS exam_id) AS src
           ON target.student_id = src.student_id AND target.exam_id = src.exam_id
         WHEN MATCHED THEN
           UPDATE SET ai_score=?, verdict=?, confidence=?, signals=?, ast_depth=?,
                      unique_vars=?, avg_line_length=?, comment_ratio=?,
                      sudden_paste=?, perfect_structure=?, checked_at=GETDATE()
         WHEN NOT MATCHED THEN
           INSERT (student_id,exam_id,ai_score,verdict,confidence,signals,ast_depth,
                   unique_vars,avg_line_length,comment_ratio,sudden_paste,perfect_structure,checked_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,GETDATE());`,
        [
          student_id, parsedExamId,
          ai.aiScore, ai.verdict, ai.confidence, JSON.stringify(ai.signals),
          ai.astDepth, ai.uniqueVars, ai.avgLineLength, ai.commentRatio, ai.suddenPaste, ai.perfectStructure,
          student_id, parsedExamId,
          ai.aiScore, ai.verdict, ai.confidence, JSON.stringify(ai.signals),
          ai.astDepth, ai.uniqueVars, ai.avgLineLength, ai.commentRatio, ai.suddenPaste, ai.perfectStructure,
        ]
      );
    }
    console.log("✓ Plagiarism + AI detection completed");
  } catch (err) { console.error("[Cron] Error:", err.message); }
});

// ─── Viva routes ──────────────────────────────────────────────────────────────

app.post("/api/viva-results", async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const {
      studentName, problemName, submittedCode, codingScore,
      overallScore, authScore, finalVerdict, completedAt, vivaAnswers,
    } = req.body;
    const [resultRow] = await conn.execute(
      `INSERT INTO viva_results
         (student_name, problem_name, submitted_code, coding_score, overall_score,
          auth_score, final_verdict, completed_at)
       OUTPUT INSERTED.id
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        studentName || "Unknown", problemName || "Solution", submittedCode || "",
        codingScore ?? null, overallScore ?? null, authScore ?? null,
        finalVerdict || "Genuine", completedAt || new Date().toISOString(),
      ]
    );
    const vivaResultId = resultRow[0]?.id;
    if (Array.isArray(vivaAnswers)) {
      for (const ans of vivaAnswers) {
        await conn.execute(
          `INSERT INTO viva_answers
             (viva_result_id,question_number,question_type,question,student_answer,duration_secs,
              score,technical_accuracy,relevance,completeness,authenticity_score,verdict,feedback,
              strengths,improvements,authenticity_reason,plagiarism_risk,signals,
              is_relevant,is_specific_to_code,relevance_feedback)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [
            vivaResultId, ans.questionNumber ?? null, ans.questionType || "",
            ans.question || "", ans.studentAnswer || "", ans.durationSecs ?? null,
            ans.score ?? null, ans.technicalAccuracy ?? null, ans.relevance ?? null,
            ans.completeness ?? null, ans.authenticityScore ?? null, ans.verdict || "",
            ans.feedback || "", JSON.stringify(ans.strengths || []),
            JSON.stringify(ans.improvements || []), ans.authenticityReason || "",
            ans.plagiarismRisk || "Low", JSON.stringify(ans.signals || []),
            ans.isRelevant ? 1 : 0, ans.isSpecificToCode ? 1 : 0,
            ans.relevanceFeedback || "",
          ]
        );
      }
    }
    await conn.commit();
    res.json({ success: true, vivaResultId });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ success: false, error: err.message });
  } finally { conn.release(); }
});

app.get("/api/viva-results", async (req, res) => {
  try {
    const [rows] = await pool.execute(`SELECT * FROM viva_results ORDER BY created_at DESC`);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get("/api/viva-results/:id", async (req, res) => {
  try {
    const [results] = await pool.execute(`SELECT * FROM viva_results WHERE id = ?`, [req.params.id]);
    if (!results.length) return res.status(404).json({ error: "Not found" });
    const [answers] = await pool.execute(
      `SELECT * FROM viva_answers WHERE viva_result_id = ? ORDER BY question_number`, [req.params.id]
    );
    res.json({
      ...results[0],
      vivaAnswers: answers.map(a => ({
        ...a,
        strengths:    JSON.parse(a.strengths    || "[]"),
        improvements: JSON.parse(a.improvements || "[]"),
      })),
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get("/api/viva-results/student/:name", async (req, res) => {
  try {
    const [rows] = await pool.execute(
      `SELECT vr.*, COUNT(va.id) AS total_answers
       FROM viva_results vr
       LEFT JOIN viva_answers va ON vr.id = va.viva_result_id
       WHERE vr.student_name = ?
       GROUP BY vr.id, vr.student_name, vr.problem_name, vr.submitted_code,
                vr.coding_score, vr.overall_score, vr.auth_score,
                vr.final_verdict, vr.completed_at, vr.created_at
       ORDER BY vr.created_at DESC`,
      [req.params.name]
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─── Code snapshot / reports routes ──────────────────────────────────────────

app.post("/api/code/save", async (req, res) => {
  try {
    const { studentId, examId, code } = req.body;
    const parsedExamId = parseInt(examId);
    if (isNaN(parsedExamId)) return res.status(400).json({ error: "examId must be a valid integer" });
    if (!studentId || !parsedExamId || code === undefined) return res.status(400).json({ error: "Missing fields" });
    await pool.execute(
      `INSERT INTO code_snapshots (student_id, exam_id, code, created_at) VALUES (?, ?, ?, GETDATE())`,
      [studentId, parsedExamId, code]
    );
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get("/api/reports/:examId", async (req, res) => {
  try {
    const examId = parseInt(req.params.examId);
    if (isNaN(examId)) return res.status(400).json({ error: "Invalid examId" });
    const [rows] = await pool.execute(
      `SELECT pr.student_id, pr.score AS plagiarism_score, pr.matched_with, pr.change_count, pr.checked_at,
              MIN(cs.created_at) AS started_at, MAX(cs.created_at) AS last_active,
              ai.ai_score, ai.verdict AS ai_verdict, ai.confidence AS ai_confidence
       FROM plagiarism_reports pr
       JOIN code_snapshots cs ON pr.student_id=cs.student_id AND pr.exam_id=cs.exam_id
       LEFT JOIN ai_detection_reports ai ON pr.student_id=ai.student_id AND pr.exam_id=ai.exam_id
       WHERE pr.exam_id=?
       GROUP BY pr.student_id, pr.score, pr.matched_with, pr.change_count, pr.checked_at,
                ai.ai_score, ai.verdict, ai.confidence
       ORDER BY pr.score DESC`,
      [examId]
    );
    res.json({ examId, students: rows });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get("/api/reports/:examId/:studentId/timeline", async (req, res) => {
  try {
    const examId = parseInt(req.params.examId);
    if (isNaN(examId)) return res.status(400).json({ error: "Invalid examId" });
    const [snapshots] = await pool.execute(
      `SELECT id, code, created_at FROM code_snapshots WHERE exam_id=? AND student_id=? ORDER BY created_at ASC`,
      [examId, req.params.studentId]
    );
    res.json({
      studentId: req.params.studentId, examId,
      timeline: snapshots.map((s, i) => ({
        snapshot: i + 1, timestamp: s.created_at,
        chars: s.code.length, lines: s.code.split("\n").length, code: s.code,
      })),
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get("/api/reports/:examId/:studentId/compare", async (req, res) => {
  try {
    const examId = parseInt(req.params.examId);
    if (isNaN(examId)) return res.status(400).json({ error: "Invalid examId" });
    const [prRows] = await pool.execute(
      `SELECT matched_with FROM plagiarism_reports WHERE student_id=? AND exam_id=?`,
      [req.params.studentId, examId]
    );
    const pr = prRows[0];
    if (!pr?.matched_with) return res.json({ match: null });
    const getLatest = async sid => {
      const [rows] = await pool.execute(
        `SELECT TOP 1 code FROM code_snapshots WHERE student_id=? AND exam_id=? ORDER BY created_at DESC`,
        [sid, examId]
      );
      return rows[0]?.code || "";
    };
    const [codeA, codeB] = await Promise.all([
      getLatest(req.params.studentId),
      getLatest(pr.matched_with),
    ]);
    res.json({
      studentA: { id: req.params.studentId, code: codeA },
      studentB: { id: pr.matched_with,      code: codeB },
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get("/api/ai-detection/:examId", async (req, res) => {
  try {
    const examId = parseInt(req.params.examId);
    if (isNaN(examId)) return res.status(400).json({ error: "Invalid examId" });
    const [rows] = await pool.execute(
      `SELECT ai.*, pr.change_count, pr.score AS plagiarism_score
       FROM ai_detection_reports ai
       LEFT JOIN plagiarism_reports pr ON ai.student_id=pr.student_id AND ai.exam_id=pr.exam_id
       WHERE ai.exam_id=? ORDER BY ai.ai_score DESC`,
      [examId]
    );
    res.json({ examId, students: rows.map(r => ({ ...r, signals: JSON.parse(r.signals || "[]") })) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get("/api/ai-detection/:examId/:studentId", async (req, res) => {
  try {
    const examId = parseInt(req.params.examId);
    if (isNaN(examId)) return res.status(400).json({ error: "Invalid examId" });
    const [rows] = await pool.execute(
      `SELECT * FROM ai_detection_reports WHERE student_id=? AND exam_id=?`,
      [req.params.studentId, examId]
    );
    const row = rows[0];
    if (!row) return res.json({ found: false });
    res.json({ found: true, ...row, signals: JSON.parse(row.signals || "[]") });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─── Root route ───────────────────────────────────────────────────────────────
app.get("/", (req, res) => res.send("NeuroAssess Backend Running ✅"));

app.locals.candidateImportSessions = new Map();

// ─── Route loading ────────────────────────────────────────────────────────────

const authRoutes         = safeRequire("./routes/auth");
const uploadRoutes       = safeRequire("./routes/upload");
const reportRoutes       = safeRequire("./routes/report");
const examRequestRoutes  = safeRequire("./routes/examRequests");
const vivaRoutes         = safeRequire("./routes/viva");
const geoRoutes          = safeRequire("./routes/geo");
const questionRoutes     = safeRequire("./routes/questions");
const candidateRoutes    = safeRequire("./routes/candidates");
const verifyRoutes       = safeRequire("./routes/verify");
const questionBankRoutes = safeRequire("./routes/questionBank");
const proctoringRoutes   = safeRequire("./routes/proctoring");
const aiRoutes           = safeRequire("./routes/ai");
const auditLogsRoutes    = safeRequire("./routes/auditLogs");
const validateRouter     = safeRequire("./routes/candidatesValidation");
const examRoutes         = safeRequire("./routes/exams");
const studentRoutes      = safeRequire("./routes/studentRoutes");
const hiringReportRoutes = safeRequire("./routes/hiringReport");
const monitoringRoutes   = safeRequire("./routes/completedExamsMonitoring");

useRoute("/api/auth",                authRoutes,           "authRoutes");
useRoute("/api",                     uploadRoutes,         "uploadRoutes");
useRoute("/api",                     reportRoutes,         "reportRoutes");
useRoute("/api/exam-requests",       examRequestRoutes,    "examRequestRoutes");
useRoute("/api/viva",                vivaRoutes,           "vivaRoutes");
useRoute("/api",                     geoRoutes,            "geoRoutes");
useRoute("/api",                     examRoutes,           "examRoutes");
useRoute("/api/questions",           questionRoutes,       "questionRoutes");
useRoute("/api/student",             studentRoutes,        "studentRoutes");
useRoute("/api/candidates/validate", validateRouter,       "candidatesValidation");
useRoute("/api/candidates",          candidateRoutes,      "candidateRoutes");
useRoute("/api",                     verifyRoutes,         "verifyRoutes");
useRoute("/api",                     questionBankRoutes,   "questionBankRoutes");
useRoute("/api/ai",                  aiRoutes,             "aiRoutes");
useRoute("/api/audit-logs",          auditLogsRoutes,      "auditLogsRoutes");
useRoute("/api",                     proctoringRoutes,     "proctoringRoutes");
useRoute("/api/hiring-report",       hiringReportRoutes,   "hiringReportRoutes");
useRoute("/api/monitoring",          monitoringRoutes,     "monitoringRoutes");

// ─── Start server ─────────────────────────────────────────────────────────────

const PORT = process.env.PORT || 5000;
const server = app.listen(PORT, async () => {
  console.log(`\n🚀 NeuroAssess backend running on port ${PORT}`);
  console.log(`🌐 Environment : ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔗 Health check: http://localhost:${PORT}/api/health\n`);
  try {
    await createTables();
    if (AuditLogger && typeof AuditLogger.ensureAuditTable === 'function') {
      await AuditLogger.ensureAuditTable();
      console.log("✓ AuditLogger table ensured");
    }
  } catch (err) { console.error("Startup error:", err.message); }
});

server.on("error", err => {
  if (err.code === "EADDRINUSE") console.error(`Port ${PORT} already in use.`);
  else console.error("Server error:", err.message);
  process.exit(1);
});

process.on("unhandledRejection", reason => { console.error("Unhandled rejection:", reason); });